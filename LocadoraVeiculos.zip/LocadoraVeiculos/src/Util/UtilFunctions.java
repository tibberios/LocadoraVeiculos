package Util;

public interface UtilFunctions {
	public void getAll();
	public void find(String string_to_find);
	public void remove(String string_to_remove);
}
