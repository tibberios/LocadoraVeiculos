package Excecoes;

public class EmailNaoCadastradoException extends Exception{
public String toString() {
	return "Email N�o Cadastrado";
}
}
