package Excecoes;

public class FormatoDadosException extends Exception{

	public String toString() {
	 return "Erro No Formato Dos Dados";
	}
}
