package Excecoes;

public class CorValidarException extends Exception{

}
