package Excecoes;

@SuppressWarnings("serial")
public class SenhaInvalidaException extends Exception{
	
	public String toString() {
		return "Senha Invalida";
	}
}